
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from './services/supabase';
import LoadingOverlay from './components/common/LoadingOverlay';
import Toast from './components/common/Toast';
import CustomerView from './components/customer/CustomerView';
import AdminPanel from './components/admin/AdminPanel';
import OrderSuccessModal from './components/customer/OrderSuccessModal';
import type { Product, CartItem, ToastState, ToastType, Order } from './types';

type View = 'customer' | 'admin';

const App: React.FC = () => {
    const [view, setView] = useState<View>('customer');
    const [products, setProducts] = useState<Product[]>([]);
    const [cart, setCart] = useState<CartItem[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [loadingText, setLoadingText] = useState('加载中...');
    const [toast, setToast] = useState<ToastState>({ show: false, message: '', type: 'success' });
    const [lastOrder, setLastOrder] = useState<Order | null>(null);

    const showToast = useCallback((message: string, type: ToastType = 'success') => {
        setToast({ show: true, message, type });
    }, []);

    const fetchProducts = useCallback(async () => {
        setIsLoading(true);
        setLoadingText('正在加载商品...');
        const { data, error } = await supabase.from('products').select('*').eq('is_published', true).order('id');
        if (error) {
            showToast(`加载商品失败: ${error.message}`, 'danger');
            setProducts([]);
        } else {
            setProducts(data as Product[]);
        }
        setIsLoading(false);
    }, [showToast]);
    
    useEffect(() => {
        fetchProducts();
         // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const addToCart = (product: Product) => {
        setCart(prevCart => {
            const existingItem = prevCart.find(item => item.id === product.id);
            if (existingItem) {
                if (product.is_unlimited || existingItem.quantity < product.stock_quantity) {
                    showToast(`${product.name} 已添加到购物车`, 'success');
                    return prevCart.map(item =>
                        item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
                    );
                } else {
                    showToast(`${product.name} 库存不足`, 'warning');
                    return prevCart;
                }
            }
            showToast(`${product.name} 已添加到购物车`, 'success');
            return [...prevCart, { ...product, quantity: 1 }];
        });
    };
    
    const updateCartQuantity = (productId: number, newQuantity: number) => {
        const product = products.find(p => p.id === productId);
        if (!product) return;

        if (newQuantity <= 0) {
            setCart(prevCart => prevCart.filter(item => item.id !== productId));
        } else if (!product.is_unlimited && newQuantity > product.stock_quantity) {
            showToast(`库存不足，最多可购买 ${product.stock_quantity} 件`, 'warning');
            setCart(prevCart => prevCart.map(item => item.id === productId ? { ...item, quantity: product.stock_quantity } : item));
        } else {
            setCart(prevCart => prevCart.map(item => item.id === productId ? { ...item, quantity: newQuantity } : item));
        }
    };
    
    const removeFromCart = (productId: number) => {
         setCart(prevCart => prevCart.filter(item => item.id !== productId));
    };

    const cartTotal = useMemo(() => {
        return cart.reduce((total, item) => total + Number(item.price) * item.quantity, 0);
    }, [cart]);
    
    const totalItems = useMemo(() => {
        return cart.reduce((sum, item) => sum + item.quantity, 0);
    }, [cart]);

    const handleOrderSuccess = (order: Order) => {
        setLastOrder(order);
        setCart([]);
        fetchProducts(); // Refresh products to update stock
    };
    
    const handleNewOrder = () => {
        setLastOrder(null);
        setView('customer');
    };

    const renderView = () => {
        if (lastOrder) {
            return <OrderSuccessModal order={lastOrder} onNewOrder={handleNewOrder} />;
        }
        
        switch (view) {
            case 'admin':
                return <AdminPanel onExit={() => setView('customer')} showToast={showToast} />;
            case 'customer':
            default:
                return <CustomerView 
                            products={products} 
                            cart={cart} 
                            addToCart={addToCart} 
                            updateCartQuantity={updateCartQuantity}
                            removeFromCart={removeFromCart}
                            cartTotal={cartTotal}
                            totalItems={totalItems}
                            showToast={showToast} 
                            isLoading={isLoading} 
                            setLastOrder={handleOrderSuccess} 
                            onAdminClick={() => setView('admin')}
                        />;
        }
    };

    return (
        <div className="bg-gray-50 min-h-screen">
            {isLoading && <LoadingOverlay text={loadingText} />}
            {toast.show && <div className="fixed top-5 right-5 z-50"><Toast message={toast.message} type={toast.type} onDismiss={() => setToast({ ...toast, show: false })} /></div>}
            <main>
                {renderView()}
            </main>
        </div>
    );
};

export default App;
