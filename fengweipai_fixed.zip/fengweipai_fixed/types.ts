
export type OrderStatus = 'pending' | 'ready_for_pickup' | 'delivered' | 'completed' | 'cancelled';

export interface Product {
    id: number;
    name: string;
    price: number;
    stock_quantity: number;
    category: string;
    image_url: string;
    emoji: string;
    min_stock_threshold: number;
    is_published: boolean;
    is_unlimited: boolean;
}

export interface CartItem extends Product {
    quantity: number;
}

export interface OrderItem {
    id: number;
    product: string;
    quantity: number;
    price: number;
    emoji: string;
    is_unlimited: boolean;
}

export interface Order {
    id: number;
    created_at: string;
    order_id: string;
    name: string;
    phone: string;
    delivery_method: string;
    payment_method: string;
    remarks: string;
    order_items: OrderItem[];
    total_amount: number;
    payment_proof_url: string;
    status: OrderStatus;
    international_shipping_fee?: number | null;
    local_shipping_fee?: number | null;
}

export interface OrderFormData {
    name: string;
    phone: string;
    delivery: string;
    remarks: string;
    paymentMethod: string;
}

export interface OrderDataContext extends OrderFormData {
    paymentProof: File;
    cart: CartItem[];
    total: number;
}

export type ToastType = 'success' | 'danger' | 'warning';

export interface ToastState {
    show: boolean;
    message: string;
    type: ToastType;
}