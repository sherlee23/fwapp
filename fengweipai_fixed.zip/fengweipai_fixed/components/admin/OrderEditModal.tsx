import React, { useState } from 'react';
import type { Order } from '../../types';

interface OrderEditModalProps {
    order: Order;
    onClose: () => void;
    onSave: (orderId: number, fees: { international_shipping_fee: number; local_shipping_fee: number; }) => void;
}

const OrderEditModal: React.FC<OrderEditModalProps> = ({ order, onClose, onSave }) => {
    const [fees, setFees] = useState({
        international_shipping_fee: order.international_shipping_fee || 0,
        local_shipping_fee: order.local_shipping_fee || 0,
    });
    const [isSaving, setIsSaving] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFees(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
    };

    const isSelfPickup = order.delivery_method === 'self-pickup';

    const handleSave = async () => {
        setIsSaving(true);
        // Create a corrected fees object to ensure data integrity before saving.
        const finalFees = {
            international_shipping_fee: fees.international_shipping_fee,
            local_shipping_fee: isSelfPickup ? 0 : fees.local_shipping_fee,
        };
        // Pass the corrected object to the onSave handler.
        await onSave(order.id, finalFees);
        setIsSaving(false);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4 animate-fade-in">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                <div className="flex justify-between items-center p-5 border-b">
                    <h2 className="text-xl font-bold">管理订单费用</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800 text-2xl">&times;</button>
                </div>
                <div className="p-6 space-y-4">
                    <div>
                        <p><strong>订单号:</strong> {order.order_id}</p>
                        <p><strong>客户:</strong> {order.name}</p>
                    </div>
                    <hr/>
                    <div>
                        <label className="font-semibold text-gray-700">国际运费 (RM)</label>
                        <input
                            type="number"
                            name="international_shipping_fee"
                            value={fees.international_shipping_fee}
                            onChange={handleChange}
                            className="w-full mt-1 p-2 border rounded border-gray-300"
                            step="0.01"
                            min="0"
                        />
                    </div>
                    <div>
                        <label className="font-semibold text-gray-700">本地运费 (RM)</label>
                        <input
                            type="number"
                            name="local_shipping_fee"
                            value={isSelfPickup ? 0 : fees.local_shipping_fee}
                            onChange={handleChange}
                            className={`w-full mt-1 p-2 border rounded ${isSelfPickup ? 'bg-gray-200 border-gray-200' : 'border-gray-300'}`}
                            step="0.01"
                            min="0"
                            disabled={isSelfPickup}
                        />
                        {isSelfPickup && <p className="text-xs text-gray-500 mt-1">自取订单无需本地运费。</p>}
                    </div>
                </div>
                <div className="px-6 py-4 bg-gray-50 flex justify-end gap-3 rounded-b-lg">
                    <button onClick={onClose} disabled={isSaving} className="px-4 py-2 bg-gray-300 text-gray-800 rounded-lg hover:bg-gray-400 disabled:opacity-50">
                        取消
                    </button>
                    <button onClick={handleSave} disabled={isSaving} className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-red-400 disabled:cursor-wait">
                        {isSaving ? '保存中...' : '保存并通知客户'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default OrderEditModal;