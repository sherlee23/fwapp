
import React from 'react';
import type { Order, OrderItem, OrderStatus } from '../../types';

interface OrderManagementPanelProps {
    orders: Order[];
    onUpdateStatus: (orderId: number, newStatus: OrderStatus, order: Order) => void;
    onManageOrder: (order: Order) => void;
}

const statusTranslations: Record<OrderStatus, string> = {
    pending: '待处理',
    ready_for_pickup: '可自取',
    delivered: '已发货',
    completed: '已完成',
    cancelled: '已取消',
};

const statusColors: Record<OrderStatus, string> = {
    pending: 'bg-yellow-200 text-yellow-800',
    ready_for_pickup: 'bg-blue-200 text-blue-800',
    delivered: 'bg-indigo-200 text-indigo-800',
    completed: 'bg-green-200 text-green-800',
    cancelled: 'bg-red-200 text-red-800',
}

const OrderManagementPanel: React.FC<OrderManagementPanelProps> = ({ orders, onUpdateStatus, onManageOrder }) => {

    const renderOrderItems = (items: OrderItem[] | undefined) => {
        if (!Array.isArray(items)) return '';
        return items.map(item => `<div>${item.emoji} ${item.product} x ${item.quantity} = RM${(item.quantity * item.price).toFixed(2)}</div>`).join('');
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-4">订单列表 ({orders.length})</h2>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-100">
                        <tr>
                            <th className="px-4 py-3">订单号</th>
                            <th className="px-4 py-3">客户</th>
                            <th className="px-4 py-3">详情</th>
                            <th className="px-4 py-3">总额</th>
                            <th className="px-4 py-3 w-40">状态</th>
                            <th className="px-4 py-3">时间</th>
                            <th className="px-4 py-3">操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        {orders.map(order => {
                            const totalAmount = (order.total_amount || 0) + (order.international_shipping_fee || 0) + (order.local_shipping_fee || 0);
                            return (
                                <tr key={order.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-4 py-4 font-medium text-gray-900 whitespace-nowrap">{order.order_id}</td>
                                    <td className="px-4 py-4">{order.name} <br/> <span className="text-xs text-gray-500">{order.phone}</span></td>
                                    <td className="px-4 py-4 text-xs" dangerouslySetInnerHTML={{ __html: renderOrderItems(order.order_items) }}></td>
                                    <td className="px-4 py-4 font-bold text-red-600">RM{totalAmount.toFixed(2)}</td>
                                    <td className="px-4 py-4">
                                        <select
                                          value={order.status}
                                          onChange={(e) => onUpdateStatus(order.id, e.target.value as OrderStatus, order)}
                                          className={`w-full p-2 text-xs border rounded-lg ${statusColors[order.status] || 'bg-gray-200 text-gray-800'}`}
                                        >
                                            {Object.keys(statusTranslations).map(status => (
                                                <option key={status} value={status}>
                                                    {statusTranslations[status as OrderStatus]}
                                                </option>
                                            ))}
                                        </select>
                                    </td>
                                    <td className="px-4 py-4 text-xs">{new Date(order.created_at!).toLocaleString('en-MY', { timeZone: 'Asia/Kuala_Lumpur' })}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">
                                        <a href={order.payment_proof_url} target="_blank" rel="noopener noreferrer" className="font-medium text-blue-600 hover:underline">查看凭证</a>
                                        <button onClick={() => onManageOrder(order)} className="font-medium text-green-600 hover:underline ml-3">管理费用</button>
                                    </td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default OrderManagementPanel;
