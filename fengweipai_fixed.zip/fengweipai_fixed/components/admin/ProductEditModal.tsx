
import React, { useState, useEffect } from 'react';
import { supabase } from '../../services/supabase';
import { PRODUCT_IMAGE_BASE_URL } from '../../constants';
import type { Product } from '../../types';

interface ProductEditModalProps {
    product: Product | null;
    onSaveSuccess: () => void;
    onClose: () => void;
}

const ProductEditModal: React.FC<ProductEditModalProps> = ({ product, onSaveSuccess, onClose }) => {
    const [formData, setFormData] = useState({
        id: product?.id || null,
        name: product?.name || '',
        price: product?.price || 0,
        stock_quantity: product?.stock_quantity || 0,
        category: product?.category || '',
        image_url: product?.image_url || '',
        emoji: product?.emoji || '',
        min_stock_threshold: product?.min_stock_threshold || 5,
        is_published: product?.is_published ?? true,
        is_unlimited: product?.is_unlimited ?? false,
    });
    const [imageFilename, setImageFilename] = useState('');

    useEffect(() => {
        if (product?.image_url) {
            try {
                const url = new URL(product.image_url);
                const pathParts = url.pathname.split('/');
                setImageFilename(pathParts[pathParts.length - 1]);
            } catch (e) {
                // If URL is not valid, just show the raw string
                setImageFilename(product.image_url.replace(PRODUCT_IMAGE_BASE_URL, ''));
            }
        }
    }, [product]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value, type, checked } = e.target;
        setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : (type === 'number' ? parseFloat(value) : value) }));
    };

    const handleFilenameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setImageFilename(e.target.value);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            const dataToSave = {
                ...formData,
                image_url: imageFilename.startsWith('http') ? imageFilename : PRODUCT_IMAGE_BASE_URL + imageFilename,
            };

            const { id, ...saveData } = dataToSave;

            const result = formData.id
                ? await supabase.from('products').update(saveData).eq('id', formData.id)
                : await supabase.from('products').insert([saveData]);
            
            if (result.error) throw result.error;
            onSaveSuccess();
        } catch (error) {
            const err = error as Error;
            alert(`保存失败: ${err.message}`);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col animate-fade-in">
                <div className="flex justify-between items-center p-5 border-b">
                    <h2 className="text-xl font-bold">{product ? '编辑商品' : '添加新商品'}</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800 text-2xl">&times;</button>
                </div>
                <form onSubmit={handleSubmit} className="flex-grow overflow-y-auto p-6 space-y-4">
                    <div>
                        <label className="font-semibold">名称</label>
                        <input type="text" name="name" value={formData.name} onChange={handleChange} className="w-full mt-1 p-2 border rounded border-gray-300" required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="font-semibold">价格 (RM)</label>
                            <input type="number" name="price" value={formData.price} onChange={handleChange} className="w-full mt-1 p-2 border rounded border-gray-300" required step="0.01" />
                        </div>
                        <div>
                            <label className="font-semibold">库存</label>
                            <input type="number" name="stock_quantity" value={formData.stock_quantity} onChange={handleChange} className="w-full mt-1 p-2 border rounded border-gray-300" required disabled={formData.is_unlimited} />
                        </div>
                    </div>
                    <div>
                        <label className="font-semibold">分类</label>
                        <input type="text" name="category" value={formData.category} onChange={handleChange} className="w-full mt-1 p-2 border rounded border-gray-300" required />
                    </div>
                    <div>
                        <label className="font-semibold">图片文件名 (例如: IMG_3859.jpeg)</label>
                        <input type="text" name="image_filename" value={imageFilename} onChange={handleFilenameChange} className="w-full mt-1 p-2 border rounded border-gray-300" required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="font-semibold">Emoji</label>
                            <input type="text" name="emoji" value={formData.emoji} onChange={handleChange} className="w-full mt-1 p-2 border rounded border-gray-300" />
                        </div>
                        <div>
                            <label className="font-semibold">低库存阈值</label>
                            <input type="number" name="min_stock_threshold" value={formData.min_stock_threshold} onChange={handleChange} className="w-full mt-1 p-2 border rounded border-gray-300" required />
                        </div>
                    </div>
                    <div className="flex items-center justify-between">
                        <span className="font-semibold">状态</span>
                        <div className="flex items-center gap-2">
                           <span className="text-gray-700">{formData.is_published ? '上架' : '下架'}</span>
                           <div className="relative inline-block w-10 mr-2 align-middle select-none">
                               <input type="checkbox" name="is_published" id="is_published" checked={formData.is_published} onChange={handleChange} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"/>
                               <label htmlFor="is_published" className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"></label>
                           </div>
                        </div>
                    </div>
                    <div className="flex items-center justify-between">
                        <span className="font-semibold">类型</span>
                        <div className="flex items-center gap-2">
                            <span className="text-gray-700">{formData.is_unlimited ? '无限购 (预购)' : '限购 (现货)'}</span>
                            <div className="relative inline-block w-10 mr-2 align-middle select-none">
                                <input type="checkbox" name="is_unlimited" id="is_unlimited" checked={formData.is_unlimited} onChange={handleChange} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"/>
                                <label htmlFor="is_unlimited" className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"></label>
                            </div>
                        </div>
                    </div>
                    <div className="p-5 border-t bg-gray-50 mt-4 -mx-6 -mb-6 rounded-b-lg">
                        <button type="submit" className="w-full bg-red-600 text-white font-bold py-3 rounded-lg hover:bg-red-700">保存商品</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ProductEditModal;
