import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../services/supabase';
import { ADMIN_PASSWORD, WHATSAPP_NUMBER } from '../../constants';
import { buildStatusUpdateMessage, buildShippingFeeMessage } from '../../utils/whatsapp';
import LoadingSpinner from '../common/LoadingSpinner';
import ProductManagementPanel from './ProductManagementPanel';
import OrderManagementPanel from './OrderManagementPanel';
import ProductEditModal from './ProductEditModal';
import OrderEditModal from './OrderEditModal'; 
import type { Product, Order, ToastType, OrderStatus } from '../../types';

interface AdminPanelProps {
    onExit: () => void;
    showToast: (message: string, type: ToastType) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onExit, showToast }) => {
    const [isAuthenticated, setAuthenticated] = useState(false);
    const [password, setPassword] = useState('');
    const [activeTab, setActiveTab] = useState<'products' | 'orders'>('products');
    const [products, setProducts] = useState<Product[]>([]);
    const [orders, setOrders] = useState<Order[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isProductModalOpen, setIsProductModalOpen] = useState(false);
    const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
    const [productToEdit, setProductToEdit] = useState<Product | null>(null);
    const [orderToEdit, setOrderToEdit] = useState<Order | null>(null);

    const fetchAllData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [productsData, ordersData] = await Promise.all([
                supabase.from('products').select('*').order('id'),
                supabase.from('orders').select('*').order('created_at', { ascending: false })
            ]);

            if (productsData.error) throw productsData.error;
            if (ordersData.error) throw ordersData.error;

            setProducts(productsData.data as Product[]);
            setOrders(ordersData.data as Order[]);
        } catch (error) {
            const err = error as Error;
            showToast(`加载后台数据失败: ${err.message}`, 'danger');
        } finally {
            setIsLoading(false);
        }
    }, [showToast]);

    useEffect(() => {
        if (isAuthenticated) {
            fetchAllData();
        }
    }, [isAuthenticated, fetchAllData]);

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (password === ADMIN_PASSWORD) {
            setAuthenticated(true);
            showToast('登录成功', 'success');
        } else {
            showToast('管理员密码错误', 'danger');
            setPassword('');
        }
    };
    
    const handleSaveProductSuccess = () => {
        setIsProductModalOpen(false);
        setProductToEdit(null);
        showToast('商品保存成功!', 'success');
        fetchAllData();
    };

    const handleEditProduct = (product: Product) => {
        setProductToEdit(product);
        setIsProductModalOpen(true);
    };

    const handleAddProduct = () => {
        setProductToEdit(null);
        setIsProductModalOpen(true);
    };

    const handleManageOrder = (order: Order) => {
        setOrderToEdit(order);
        setIsOrderModalOpen(true);
    }
    
    const handleUpdateStatus = async (orderId: number, status: OrderStatus, order: Order) => {
        try {
            const { error } = await supabase.from('orders').update({ status }).eq('id', orderId);
            if (error) throw error;

            showToast(`订单 #${order.order_id} 状态已更新`, 'success');
            await fetchAllData();

            const message = buildStatusUpdateMessage(order, status);
            const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
        } catch(error) {
            const err = error as Error;
            showToast(`状态更新失败: ${err.message}`, 'danger');
        }
    };
    
    const handleSaveOrderFees = async (orderId: number, fees: { international_shipping_fee: number; local_shipping_fee: number; }) => {
        try {
            // Step 1: Perform the update without a select chain, to avoid SELECT RLS issues.
            const { error } = await supabase
                .from('orders')
                .update(fees)
                .eq('id', orderId);

            if (error) {
                // This will now catch update-specific errors, like RLS on the UPDATE policy.
                throw error;
            }

            // Step 2: Find the original order from local state to build the notification.
            const originalOrder = orders.find(o => o.id === orderId);
            if (!originalOrder) {
                throw new Error("在本地状态中找不到订单。");
            }
            
            // Step 3: Manually construct the 'updated' order object for the WhatsApp message.
            const updatedOrderForMessage: Order = {
                ...originalOrder,
                ...fees,
            };

            showToast(`订单 #${updatedOrderForMessage.order_id} 运费已更新`, 'success');
            setIsOrderModalOpen(false);
            setOrderToEdit(null);
            await fetchAllData(); // Refresh UI with the true data from the database.

            // Step 4: Build and send the WhatsApp message.
            const message = buildShippingFeeMessage(updatedOrderForMessage);
            const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank', 'noopener,noreferrer');

        } catch (error) {
            const err = error as Error;
            // Provide a more helpful error message in case of RLS issues.
            const friendlyMessage = err.message.includes('Row-Level Security') 
                ? '权限不足。请检查数据库的行级安全(RLS)策略是否允许更新操作。'
                : err.message;
            showToast(`运费更新失败: ${friendlyMessage}`, 'danger');
        }
    };


    if (!isAuthenticated) {
        return (
            <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
              <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-sm relative">
                <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">管理员登录</h2>
                <form onSubmit={handleLogin} className="space-y-4">
                  <div>
                    <label htmlFor="password-admin" className="sr-only">Password</label>
                    <input
                      id="password-admin"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="请输入管理员密码"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:border-red-500 focus:ring-red-500"
                      autoFocus
                    />
                  </div>
                  <button type="submit" className="w-full bg-red-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-red-700 transition-colors shadow-md active:scale-95">
                    登录
                  </button>
                  <button type="button" onClick={onExit} className="w-full bg-gray-200 text-gray-800 font-bold py-3 px-4 rounded-lg hover:bg-gray-300 transition-colors mt-2">
                    返回商店
                  </button>
                </form>
              </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-100 p-4 sm:p-6 lg:p-8">
            <div className="max-w-7xl mx-auto">
                <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                    <h1 className="text-3xl font-bold text-gray-800">管理后台</h1>
                    <button onClick={onExit} className="bg-gray-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors">
                        返回商店
                    </button>
                </header>

                <div className="mb-4 border-b border-gray-200">
                    <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                        <button onClick={() => setActiveTab('products')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'products' ? 'border-red-600 text-red-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                            商品管理
                        </button>
                        <button onClick={() => setActiveTab('orders')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'orders' ? 'border-red-600 text-red-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                            订单管理
                        </button>
                    </nav>
                </div>
                
                {isLoading ? <div className="flex justify-center p-10"><LoadingSpinner /></div> : (
                    <div>
                        {activeTab === 'orders' && <OrderManagementPanel orders={orders} onUpdateStatus={handleUpdateStatus} onManageOrder={handleManageOrder} />}
                        {activeTab === 'products' && <ProductManagementPanel products={products} onAddProduct={handleAddProduct} onEditProduct={handleEditProduct} />}
                    </div>
                )}
            </div>
            {isProductModalOpen && <ProductEditModal onClose={() => setIsProductModalOpen(false)} onSaveSuccess={handleSaveProductSuccess} product={productToEdit} />}
            {isOrderModalOpen && orderToEdit && <OrderEditModal order={orderToEdit} onClose={() => setIsOrderModalOpen(false)} onSave={handleSaveOrderFees} />}
        </div>
    );
};

export default AdminPanel;