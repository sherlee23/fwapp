
import React from 'react';
import type { Product } from '../../types';

interface ProductManagementPanelProps {
    products: Product[];
    onAddProduct: () => void;
    onEditProduct: (product: Product) => void;
}

const ProductManagementPanel: React.FC<ProductManagementPanelProps> = ({ products, onAddProduct, onEditProduct }) => (
    <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">商品列表 ({products.length})</h2>
            <button onClick={onAddProduct} className="bg-red-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-red-700">添加商品</button>
        </div>
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-gray-500">
                <thead className="text-xs text-gray-700 uppercase bg-gray-100">
                    <tr>
                        <th className="px-6 py-3">ID</th>
                        <th className="px-6 py-3">商品</th>
                        <th className="px-6 py-3">价格</th>
                        <th className="px-6 py-3">库存</th>
                        <th className="px-6 py-3">状态</th>
                        <th className="px-6 py-3">操作</th>
                    </tr>
                </thead>
                <tbody>
                    {products.map(product => (
                        <tr key={product.id} className="bg-white border-b hover:bg-gray-50">
                            <td className="px-6 py-4">{product.id}</td>
                            <td className="px-6 py-4 font-medium text-gray-900">{product.emoji} {product.name}</td>
                            <td className="px-6 py-4">RM{Number(product.price).toFixed(2)}</td>
                            <td className="px-6 py-4">{product.is_unlimited ? '无限 (预购)' : product.stock_quantity}</td>
                            <td className="px-6 py-4">
                                <span className={`text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full ${product.is_published ? 'bg-green-200 text-green-800' : 'bg-gray-200 text-gray-800'}`}>
                                    {product.is_published ? '已上架' : '已下架'}
                                </span>
                            </td>
                            <td className="px-6 py-4">
                                <button onClick={() => onEditProduct(product)} className="font-medium text-blue-600 hover:underline">编辑</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    </div>
);

export default ProductManagementPanel;
