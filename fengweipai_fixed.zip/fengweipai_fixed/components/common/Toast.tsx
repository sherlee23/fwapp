
import React, { useEffect } from 'react';
import { ToastType } from '../../types';

interface ToastProps {
    message: string;
    type: ToastType;
    onDismiss: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, type, onDismiss }) => {
    const baseClasses = "flex items-center w-full max-w-xs p-4 space-x-4 text-gray-500 bg-white divide-x divide-gray-200 rounded-lg shadow-lg";
    const typeClasses: { [key in ToastType]: string } = { success: "text-green-500", danger: "text-red-500", warning: "text-yellow-500" };
    const icons: { [key in ToastType]: React.ReactNode } = {
        success: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>,
        danger: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd"></path></svg>,
        warning: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M8.257 3.099c.636-1.214 2.852-1.214 3.488 0l6.114 11.638c.636 1.214-.474 2.763-1.744 2.763H3.887c-1.27 0-2.38-1.549-1.744-2.763L8.257 3.099zM10 6a1 1 0 011 1v4a1 1 0 11-2 0V7a1 1 0 011-1zm-1 8a1 1 0 102 0 1 1 0 00-2 0z" clipRule="evenodd"></path></svg>,
    };

    useEffect(() => {
        const timer = setTimeout(onDismiss, 3000);
        return () => clearTimeout(timer);
    }, [onDismiss]);

    return (
        <div className={`${baseClasses} animate-slide-in-down`}>
            <div className={`${typeClasses[type]}`}>{icons[type]}</div>
            <div className="pl-4 text-sm font-normal">{message}</div>
        </div>
    );
};

export default Toast;
