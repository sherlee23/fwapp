
import React from 'react';
import LoadingSpinner from './LoadingSpinner';

interface LoadingOverlayProps {
    text: string;
}

const LoadingOverlay: React.FC<LoadingOverlayProps> = ({ text }) => (
    <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex justify-center items-center z-50">
        <div className="text-center text-white">
            <LoadingSpinner text={text} />
        </div>
    </div>
);

export default LoadingOverlay;
