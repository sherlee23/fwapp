
import React from 'react';
import type { Product } from '../../types';

interface ProductCardProps {
    product: Product;
    onAddToCart: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart }) => {
    const isOutOfStock = !product.is_unlimited && product.stock_quantity === 0;
    const isLowStock = !product.is_unlimited && product.stock_quantity > 0 && product.min_stock_threshold && product.stock_quantity <= product.min_stock_threshold;
    const productTypeLabel = product.is_unlimited ? '(预购)' : '(现货)';

    return (
        <div className={`bg-white rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300 flex flex-col overflow-hidden ${isOutOfStock ? 'opacity-60 bg-gray-100' : ''}`}>
            <div className="relative">
                <div className="w-full h-52 bg-gray-200 flex items-center justify-center">
                    <img src={product.image_url} alt={product.name} className="w-full h-full object-contain" onError={(e) => { const target = e.target as HTMLImageElement; target.onerror = null; target.src = `https://placehold.co/400x400/cccccc/ffffff?text=Image+Error`; }} />
                </div>
                {isOutOfStock && <div className="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-full">已售完</div>}
                {isLowStock && <div className="absolute top-2 right-2 bg-yellow-500 text-black text-xs font-bold px-2 py-1 rounded-full">库存紧张</div>}
            </div>
            <div className="p-5 flex flex-col flex-grow">
                <h3 className="text-lg font-bold text-gray-800">{product.emoji} {product.name} <span className="text-sm font-normal text-gray-500">{productTypeLabel}</span></h3>
                <p className="text-sm text-gray-500 mb-3">库存: {product.is_unlimited ? '充足' : product.stock_quantity}</p>
                <div className="mt-auto">
                    <div className="flex justify-between items-center">
                        <p className="text-xl font-extrabold text-red-600">RM{Number(product.price).toFixed(2)}</p>
                        <button
                            onClick={() => onAddToCart(product)}
                            disabled={isOutOfStock}
                            className="bg-red-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-red-700 transition-colors duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                            <i className="fas fa-cart-plus"></i>
                            添加
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProductCard;
