import React, { useState, useMemo } from 'react';
import { supabase } from '../../services/supabase';
import { buildWhatsAppMessage } from '../../utils/whatsapp';
import type { OrderDataContext, ToastType, Order, CartItem } from '../../types';

interface ConfirmationModalProps {
    orderData: OrderDataContext;
    onConfirm: (finalOrder: Order) => void;
    onCancel: () => void;
    showToast: (message: string, type: ToastType) => void;
}

const generateOrderId = async (): Promise<string> => {
    const today = new Date();
    const datePrefix = `FW${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, '0')}${String(today.getDate()).padStart(2, '0')}`;
    try {
        const { count, error } = await supabase
            .from('orders')
            .select('order_id', { count: 'exact', head: true })
            .like('order_id', `${datePrefix}%`);

        if (error) throw error;
        return `${datePrefix}${String((count || 0) + 1).padStart(3, '0')}`;
    } catch (error) {
        console.warn('Could not get order count, using timestamp ID as fallback', error);
        return `FW${Date.now().toString().slice(-8)}`;
    }
};


const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ orderData, onConfirm, onCancel, showToast }) => {
    const [isSubmitting, setIsSubmitting] = useState(false);

    const whatsappPreviewMessage = useMemo(() => {
        // This is just a visual placeholder for the user. The real ID is generated on submit.
        const tempOrderId = `FW${new Date().toISOString().slice(0, 10).replace(/-/g, '')}XXX (示例)`;
        return buildWhatsAppMessage({ ...orderData, order_id: tempOrderId });
    }, [orderData]);

    const handleSubmit = async () => {
        setIsSubmitting(true);
        try {
            const { paymentProof, cart, total, ...formData } = orderData;
            
            const orderId = await generateOrderId();
            
            const fileExt = paymentProof.name.split('.').pop();
            const newFileName = `${orderId}.${fileExt}`;
            const { error: uploadError } = await supabase.storage.from('payment-proofs').upload(`proofs/${newFileName}`, paymentProof);
            if (uploadError) throw new Error(`凭证上传失败: ${uploadError.message}`);
            
            const { data: { publicUrl } } = supabase.storage.from('payment-proofs').getPublicUrl(`proofs/${newFileName}`);
            if (!publicUrl) throw new Error('无法获取凭证的公共链接');

            const finalOrderData: Omit<Order, 'id' | 'created_at'> = {
                order_id: orderId,
                name: formData.name,
                phone: formData.phone,
                delivery_method: formData.delivery,
                payment_method: formData.paymentMethod,
                remarks: formData.remarks,
                order_items: cart.map((item: CartItem) => ({ 
                    id: item.id, 
                    product: item.name, 
                    quantity: item.quantity, 
                    price: item.price, 
                    emoji: item.emoji, 
                    is_unlimited: item.is_unlimited 
                })),
                total_amount: total,
                payment_proof_url: publicUrl,
                status: 'pending'
            };
            
            const { data: insertedOrder, error: insertError } = await supabase
                .from('orders')
                .insert([finalOrderData])
                .select()
                .single();

            if (insertError) {
                throw new Error(`订单提交失败: ${insertError.message}`);
            }

            if (!insertedOrder) {
                throw new Error('订单提交失败，但未收到明确错误。这可能是由于数据库权限(RLS)策略阻止了写入。请联系管理员。');
            }
            
            for (const item of cart) {
                if (!item.is_unlimited) {
                    const { error: stockError } = await supabase.rpc('decrease_stock', {
                        p_id: item.id,
                        p_quantity: item.quantity
                    });
                    if (stockError) console.error(`产品 ${item.id} 库存更新失败: ${stockError.message}`);
                }
            }
            
            showToast('订单提交成功!', 'success');
            onConfirm(insertedOrder as Order);

        } catch (error) {
            const err = error as Error;
            showToast(`发生错误: ${err.message}`, 'danger');
        } finally {
            setIsSubmitting(false);
        }
    };
    

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg animate-fade-in">
                <div className="p-6">
                    <h2 className="text-xl font-bold text-center mb-4">订单确认</h2>
                    <div className="space-y-2 text-sm">
                        <p><strong>姓名:</strong> {orderData.name}</p>
                        <p><strong>电话:</strong> {orderData.phone}</p>
                        <p><strong>取货方式:</strong> {orderData.delivery === 'self-pickup' ? '自取' : 'Lalamove'}</p>
                        <p><strong>付款方式:</strong> {orderData.paymentMethod}</p>
                        <hr className="my-2"/>
                        <h3 className="font-semibold">订单明细:</h3>
                        <ul className="list-disc list-inside pl-4">
                            {orderData.cart.map(item => (
                                <li key={item.id}>{item.emoji} {item.name} x {item.quantity} = RM{(Number(item.price) * item.quantity).toFixed(2)}</li>
                            ))}
                        </ul>
                        <hr className="my-2"/>
                        <p className="text-right font-bold text-lg">总金额: <span className="text-red-600">RM{orderData.total.toFixed(2)}</span></p>
                        <div className="mt-4 p-3 bg-gray-100 rounded-md">
                            <h4 className="font-semibold mb-2">WhatsApp 预览信息:</h4>
                            <pre className="text-xs whitespace-pre-wrap bg-white p-2 rounded border border-gray-300 max-h-40 overflow-y-auto">
                                {whatsappPreviewMessage}
                            </pre>
                        </div>
                    </div>
                </div>
                <div className="px-6 py-4 bg-gray-50 flex justify-between rounded-b-lg">
                    <button onClick={onCancel} disabled={isSubmitting} className="px-4 py-2 bg-gray-300 text-gray-800 rounded-lg hover:bg-gray-400 disabled:opacity-50">
                        返回修改
                    </button>
                    <button onClick={handleSubmit} disabled={isSubmitting} className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-red-400 disabled:cursor-wait">
                        {isSubmitting ? '提交中...' : '确认并提交'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ConfirmationModal;