
import React, { useState } from 'react';
import { SELF_PICKUP_ADDRESS } from '../../constants';
import type { OrderDataContext, ToastType } from '../../types';

interface CheckoutModalProps {
    onClose: () => void;
    onConfirm: (data: Omit<OrderDataContext, 'cart' | 'total'> & { paymentProof: File }) => void;
    showToast: (message: string, type: ToastType) => void;
}

const CheckoutModal: React.FC<CheckoutModalProps> = ({ onClose, onConfirm, showToast }) => {
    const [formData, setFormData] = useState({ name: '', phone: '', delivery: '', remarks: '', paymentMethod: '' });
    const [paymentProof, setPaymentProof] = useState<File | null>(null);
    const [fileName, setFileName] = useState('');
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [agree, setAgree] = useState(false);

    const validate = () => {
        const newErrors: { [key: string]: string } = {};
        if (!agree) newErrors.agree = '请阅读并同意条款';
        if (!formData.name.trim()) newErrors.name = '请输入姓名';
        if (!formData.phone || !/^(\+?6?01)[0-46-9]-?[0-9]{7,8}$/.test(formData.phone)) newErrors.phone = '请输入有效的电话号码';
        if (!formData.delivery) newErrors.delivery = '请选择取货方式';
        if (!formData.paymentMethod) newErrors.paymentMethod = '请选择付款方式';
        if (!paymentProof) newErrors.paymentProof = '请上传支付凭证';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setPaymentProof(file);
            setFileName(file.name);
        }
    };

    const handleNextStep = (e: React.FormEvent) => {
        e.preventDefault();
        if (!validate()) {
            showToast('请填写所有必填项', 'warning');
            return;
        }
        if (paymentProof) {
            onConfirm({ ...formData, paymentProof });
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col animate-fade-in">
                <div className="flex justify-between items-center p-5 border-b">
                    <h2 className="text-xl font-bold">填写订单信息</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800 text-2xl">&times;</button>
                </div>
                <form onSubmit={handleNextStep} className="flex-grow overflow-y-auto p-6 space-y-6">
                    <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400 text-yellow-700">
                        <h4 className="font-bold">重要声明</h4>
                        <ul className="list-disc list-inside text-sm space-y-1 mt-2">
                            <li>此为预购商品，等待时间约30-60天。</li>
                            <li>价格不含本地运费，可自取或安排Lalamove (RM20)。</li>
                        </ul>
                        <div className="mt-4">
                            <label className="flex items-center">
                                <input type="checkbox" checked={agree} onChange={() => setAgree(!agree)} className="h-4 w-4 text-red-600 border-gray-300 rounded focus:ring-red-500" />
                                <span className="ml-2 text-sm text-gray-900">我已阅读并同意上述条款</span>
                            </label>
                            {errors.agree && <p className="text-red-500 text-xs mt-1">{errors.agree}</p>}
                        </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="font-semibold">姓名 *</label>
                            <input type="text" name="name" value={formData.name} onChange={handleChange} className={`w-full mt-1 p-2 border rounded ${errors.name ? 'border-red-500' : 'border-gray-300'}`} />
                            {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                        </div>
                        <div>
                            <label className="font-semibold">电话 *</label>
                            <input type="tel" name="phone" value={formData.phone} onChange={handleChange} className={`w-full mt-1 p-2 border rounded ${errors.phone ? 'border-red-500' : 'border-gray-300'}`} />
                            {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                        </div>
                        <div>
                            <label className="font-semibold">取货方式 *</label>
                            <select name="delivery" value={formData.delivery} onChange={handleChange} className={`w-full mt-1 p-2 border rounded ${errors.delivery ? 'border-red-500' : 'border-gray-300'}`}>
                                <option value="">请选择</option>
                                <option value="self-pickup">自取</option>
                                <option value="lalamove">Lalamove</option>
                            </select>
                            {errors.delivery && <p className="text-red-500 text-xs mt-1">{errors.delivery}</p>}
                        </div>
                        {formData.delivery === 'self-pickup' && (
                            <div className="md:col-span-2 p-3 bg-blue-50 border border-blue-200 rounded-md text-sm">
                                <p><strong>自取地址:</strong> {SELF_PICKUP_ADDRESS}</p>
                            </div>
                        )}
                        <div>
                            <label className="font-semibold">付款方式 *</label>
                            <select name="paymentMethod" value={formData.paymentMethod} onChange={handleChange} className={`w-full mt-1 p-2 border rounded ${errors.paymentMethod ? 'border-red-500' : 'border-gray-300'}`}>
                                <option value="">请选择</option>
                                <option value="Maybank QR">Maybank (DuitNow QR)</option>
                                <option value="TNG eWallet">TNG eWallet (DuitNow QR)</option>
                            </select>
                            {errors.paymentMethod && <p className="text-red-500 text-xs mt-1">{errors.paymentMethod}</p>}
                        </div>
                        <div className="md:col-span-2 flex justify-center items-start gap-4">
                            {formData.paymentMethod === 'Maybank QR' && (
                                <div className="text-center">
                                    <img src="https://edfnhhthztskuuosuasw.supabase.co/storage/v1/object/public/product-photos/IMG_4042.png" alt="Maybank QR Code" className="w-40 h-40 rounded-lg shadow-md mx-auto" />
                                    <div className="mt-2 text-sm bg-gray-100 p-2 rounded">
                                        <p><strong>户口名称:</strong> Choong Sher Lee</p>
                                        <p><strong>户口号码:</strong> 114209540438</p>
                                    </div>
                                </div>
                            )}
                            {formData.paymentMethod === 'TNG eWallet' && (
                                <div className="text-center">
                                    <img src="https://edfnhhthztskuuosuasw.supabase.co/storage/v1/object/public/product-photos/IMG_4043.jpeg" alt="TNG eWallet DuitNow QR Code" className="w-40 h-40 rounded-lg shadow-md mx-auto" />
                                </div>
                            )}
                        </div>
                        <div className="md:col-span-2">
                            <label className="font-semibold">上传转账凭证 *</label>
                            <div className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 ${errors.paymentProof ? 'border-red-500' : 'border-gray-300'} border-dashed rounded-md`}>
                                <div className="space-y-1 text-center">
                                    <i className="fas fa-cloud-upload-alt text-4xl text-gray-400"></i>
                                    <div className="flex text-sm text-gray-600">
                                        <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-red-600 hover:text-red-500 focus-within:outline-none">
                                            <span>上传文件</span>
                                            <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/*,.pdf" />
                                        </label>
                                        <p className="pl-1">或拖拽到此处</p>
                                    </div>
                                    <p className="text-xs text-gray-500">{fileName || 'PNG, JPG, PDF'}</p>
                                </div>
                            </div>
                            {errors.paymentProof && <p className="text-red-500 text-xs mt-1">{errors.paymentProof}</p>}
                        </div>
                        <div className="md:col-span-2">
                            <label className="font-semibold">备注</label>
                            <textarea name="remarks" value={formData.remarks} onChange={handleChange} rows={3} className="w-full mt-1 p-2 border border-gray-300 rounded"></textarea>
                        </div>
                    </div>
                </form>
                <div className="p-5 border-t bg-gray-50">
                    <button onClick={handleNextStep} className="w-full bg-red-600 text-white font-bold py-3 rounded-lg hover:bg-red-700 transition-colors">
                        确认订单
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CheckoutModal;
