
import React, { useState, useMemo } from 'react';
import ProductCard from './ProductCard';
import LoadingSpinner from '../common/LoadingSpinner';
import CartSidebar from './CartSidebar';
import CheckoutModal from './CheckoutModal';
import ConfirmationModal from './ConfirmationModal';
import type { Product, CartItem, ToastType, Order, OrderDataContext } from '../../types';

interface CustomerViewProps {
    products: Product[];
    cart: CartItem[];
    addToCart: (product: Product) => void;
    updateCartQuantity: (productId: number, newQuantity: number) => void;
    removeFromCart: (productId: number) => void;
    cartTotal: number;
    totalItems: number;
    showToast: (message: string, type: ToastType) => void;
    isLoading: boolean;
    setLastOrder: (order: Order) => void;
    onAdminClick: () => void;
}

const CustomerView: React.FC<CustomerViewProps> = (props) => {
    const { products, cart, addToCart, updateCartQuantity, removeFromCart, cartTotal, totalItems, showToast, isLoading, setLastOrder, onAdminClick } = props;

    const [isCartOpen, setIsCartOpen] = useState(false);
    const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [orderData, setOrderData] = useState<OrderDataContext | null>(null);

    const categories = useMemo(() => {
      const uniqueCategories = new Set(products.map(p => p.category).filter(Boolean));
      return ['全部商品', ...Array.from(uniqueCategories)];
    }, [products]);
    const [activeCategory, setActiveCategory] = useState('全部商品');

    const filteredProducts = useMemo(() => {
        if (activeCategory === '全部商品') return products;
        return products.filter(p => p.category === activeCategory);
    }, [products, activeCategory]);
    
    const handleOrderSuccess = (finalOrder: Order) => {
        setIsConfirmOpen(false);
        setIsCheckoutOpen(false);
        setLastOrder(finalOrder);
    };

    const handleConfirmCheckout = (data: Omit<OrderDataContext, 'cart' | 'total'> & { paymentProof: File }) => {
        setOrderData({
            ...data,
            cart: cart,
            total: cartTotal,
        });
        setIsCheckoutOpen(false);
        setIsConfirmOpen(true);
    };

    return (
        <div>
            <header className="bg-white shadow-md sticky top-0 z-40">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between items-center py-4">
                        <div className="flex items-center gap-3">
                            <i className="fas fa-utensils text-3xl text-red-600"></i>
                            <h1 className="text-2xl font-bold text-gray-800">锋味派美食团购</h1>
                        </div>
                        <button onClick={onAdminClick} className="text-gray-600 hover:text-red-600 transition-colors">
                            <i className="fas fa-user-shield text-2xl"></i>
                        </button>
                    </div>
                </div>
            </header>
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="mb-8 sticky top-[80px] bg-gray-50/90 backdrop-blur-sm py-3 z-30">
                    <div className="flex space-x-2 overflow-x-auto pb-2">
                        {categories.map(category => (
                            <button
                                key={category}
                                onClick={() => setActiveCategory(category)}
                                className={`px-4 py-2 text-sm font-semibold rounded-full whitespace-nowrap transition-colors ${activeCategory === category ? 'bg-red-600 text-white shadow' : 'bg-white text-gray-700 hover:bg-gray-200'}`}
                            >
                                {category}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {isLoading ? (
                        <div className="col-span-full text-center p-10"><LoadingSpinner text="加载商品中..." /></div>
                    ) : products.length === 0 ? (
                            <p className="col-span-full text-center text-gray-500">暂无商品，请联系管理员添加。</p>
                    ) : filteredProducts.length > 0 ? (
                        filteredProducts.map(product => (
                            <ProductCard key={product.id} product={product} onAddToCart={addToCart} />
                        ))
                    ) : (
                        <p className="col-span-full text-center text-gray-500">该分类下暂无商品。</p>
                    )}
                </div>

                {cart.length > 0 && (
                    <div className="fixed bottom-6 right-6 z-40">
                        <button onClick={() => setIsCartOpen(true)} className="bg-red-600 text-white rounded-full p-4 shadow-lg hover:bg-red-700 transition-transform transform hover:scale-110 flex items-center gap-3">
                            <i className="fas fa-shopping-cart text-2xl"></i>
                            <span className="font-bold text-lg">RM{cartTotal.toFixed(2)}</span>
                            <span className="absolute -top-2 -right-2 bg-yellow-400 text-black text-xs font-bold rounded-full h-6 w-6 flex items-center justify-center">{totalItems}</span>
                        </button>
                    </div>
                )}
                
                <CartSidebar 
                    isOpen={isCartOpen}
                    cart={cart} 
                    updateQuantity={updateCartQuantity}
                    removeFromCart={removeFromCart}
                    totalPrice={cartTotal}
                    onClose={() => setIsCartOpen(false)} 
                    onCheckout={() => { setIsCartOpen(false); setIsCheckoutOpen(true); }} 
                />
                
                {isCheckoutOpen && <CheckoutModal onClose={() => setIsCheckoutOpen(false)} onConfirm={handleConfirmCheckout} showToast={showToast} />}
                
                {isConfirmOpen && orderData && <ConfirmationModal orderData={orderData} onConfirm={handleOrderSuccess} onCancel={() => { setIsConfirmOpen(false); setIsCheckoutOpen(true); }} showToast={showToast} />}
            </div>
        </div>
    );
};

export default CustomerView;
