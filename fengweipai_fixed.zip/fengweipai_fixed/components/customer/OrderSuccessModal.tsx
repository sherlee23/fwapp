
import React from 'react';
import { WHATSAPP_NUMBER } from '../../constants';
import { buildWhatsAppMessage } from '../../utils/whatsapp';
import type { Order } from '../../types';

interface OrderSuccessModalProps {
    order: Order;
    onNewOrder: () => void;
}

const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({ order, onNewOrder }) => {
    
    const handleWhatsAppRedirect = () => {
        try {
            const message = buildWhatsAppMessage(order);
            const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
        } catch (error) {
            console.error('WhatsApp redirect error:', error);
            alert('无法打开 WhatsApp，请手动联系客服。');
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
            <div className="bg-white p-8 rounded-lg shadow-xl text-center max-w-md w-full animate-fade-in">
                <i className="fas fa-check-circle text-5xl text-green-500 mb-4"></i>
                <h2 className="text-2xl font-bold mb-2">订单提交成功!</h2>
                <p className="text-gray-600 mb-4">您的订单号是:</p>
                <p className="text-lg font-bold bg-gray-100 p-2 rounded-md mb-6">{order.order_id}</p>
                
                <button 
                    onClick={handleWhatsAppRedirect}
                    className="block w-full bg-green-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-600 transition-colors mb-3 text-center flex items-center justify-center gap-2"
                >
                    <i className="fab fa-whatsapp"></i> 前往 WhatsApp 发送订单
                </button>

                <button onClick={onNewOrder} className="w-full bg-gray-300 text-gray-800 font-bold py-3 px-4 rounded-lg hover:bg-gray-400 transition-colors">
                    创建新订单
                </button>
            </div>
        </div>
    );
};

export default OrderSuccessModal;
