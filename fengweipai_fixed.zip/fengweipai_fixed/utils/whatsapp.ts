
import { SELF_PICKUP_ADDRESS } from '../constants';
import type { Order, CartItem, OrderDataContext, OrderItem, OrderStatus } from '../types';

type OrderForMessage = Partial<Order> & Partial<OrderDataContext> & { order_id: string; };

export const buildWhatsAppMessage = (order: OrderForMessage): string => {
    let msg = `🛎️ *锋味派新订单 #${order.order_id}*\n\n`;
    msg += `👤 *客户信息*\n`;
    msg += `  - 姓名: ${order.name}\n`;
    msg += `  - 电话: ${order.phone}\n`;
    const deliveryMethod = order.delivery_method || order.delivery;
    msg += `  - 取货: ${deliveryMethod === 'self-pickup' ? '自取' : 'Lalamove'}\n`;
    msg += `  - 付款方式: ${order.payment_method || order.paymentMethod}\n`;
    if (deliveryMethod === 'self-pickup') {
        msg += `  - 地址: ${SELF_PICKUP_ADDRESS}\n`;
    }
    msg += `\n🛒 *订单明细*\n`;
    
    const items: (CartItem | OrderItem)[] = order.order_items || order.cart || [];
    items.forEach(item => {
        const typeLabel = item.is_unlimited ? ' (预购)' : ' (现货)';
        const itemName = 'product' in item ? item.product : item.name;
        msg += `${item.emoji} ${itemName}${typeLabel} × ${item.quantity} = RM${(item.quantity * item.price).toFixed(2)}\n`;
    });

    const totalAmount = order.total_amount ?? order.total ?? 0;
    msg += `\n💰 *总金额: RM${totalAmount.toFixed(2)}*\n`;
    msg += `📝 *备注*: ${order.remarks || '无'}\n`;
    msg += `\n📅 *下单时间*: ${new Date().toLocaleString('en-MY', { timeZone: 'Asia/Kuala_Lumpur' })}`;
    return msg;
};


export const buildStatusUpdateMessage = (order: Order, newStatus: OrderStatus): string => {
    let msg = `Hi ${order.name},\n\n`;
    msg += `订单状态更新 - *订单 #${order.order_id}*\n\n`;

    switch (newStatus) {
        case 'ready_for_pickup':
            msg += `您的订单已准备好，可以前来领取！\n`;
            msg += `取货地址: ${SELF_PICKUP_ADDRESS}`;
            break;
        case 'delivered':
            msg += `您的订单已发货，请注意查收。`;
            break;
        case 'completed':
            msg += `您的订单已完成。感谢您的惠顾！`;
            break;
        case 'cancelled':
            msg += `您的订单已被取消。如有疑问，请联系我们。`;
            break;
        default:
            msg = `您的订单 #${order.order_id} 状态已更新为: ${newStatus}`;
    }
    msg += `\n\n感谢您选择锋味派！`
    return msg;
};


export const buildShippingFeeMessage = (order: Order): string => {
    const internationalFee = order.international_shipping_fee || 0;
    const localFee = order.local_shipping_fee || 0;
    const newTotal = order.total_amount + internationalFee + localFee;

    let msg = `Hi ${order.name},\n\n`;
    msg += `运费通知 - *订单 #${order.order_id}*\n\n`;
    msg += `您的订单运费已更新，详情如下:\n`;
    if(internationalFee > 0) {
      msg += `- 国际运费: *RM${internationalFee.toFixed(2)}*\n`;
    }
    if(localFee > 0) {
      msg += `- 本地运费: *RM${localFee.toFixed(2)}*\n`;
    }
    msg += `\n订单原金额: RM${order.total_amount.toFixed(2)}\n`;
    msg += `更新后总额: *RM${newTotal.toFixed(2)}*\n\n`;
    msg += `请按此总额进行后续付款。如有疑问，请随时联系我们。`;

    return msg;
};